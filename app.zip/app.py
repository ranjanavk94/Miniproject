# app.py
import os, re, datetime, json, ast
from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import (
    JWTManager, create_access_token, jwt_required, get_jwt_identity
)
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()
print(os.getenv("SECRET_KEY"))

# optional OpenAI SDK (used only if OPENAI_API_KEY present)
try:
    import openai
except Exception:
    openai = None

# App + config
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///codehealer.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'dev-jwt-secret')
CORS(app)

db = SQLAlchemy(app)
jwt = JWTManager(app)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(120))
    last_name = db.Column(db.String(120))
    email = db.Column(db.String(200), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), default='user')
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    debug_count = db.Column(db.Integer, default=0)
    bugs_fixed = db.Column(db.Integer, default=0)

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)

    def to_dict(self):
        return {
            'id': self.id,
            'firstName': self.first_name,
            'lastName': self.last_name,
            'email': self.email,
            'role': self.role,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'lastLogin': self.last_login.isoformat() if self.last_login else None,
            'debugCount': self.debug_count,
            'bugsFixed': self.bugs_fixed
        }

# Initialize DB (only once, at first request)
@app.before_request
def create_tables():
    db.create_all()

# -------------------------------------------------------------------
# Frontend route (serves lgf.html)
# -------------------------------------------------------------------
@app.route('/')
def index():
    return render_template('lgf.html')

# -------------------------------------------------------------------
# Auth endpoints
# -------------------------------------------------------------------
@app.route('/api/signup', methods=['POST'])
def signup():
    data = request.get_json() or {}
    first = data.get('firstName') or data.get('first') or data.get('first_name')
    last = data.get('lastName') or data.get('last') or data.get('last_name')
    email = (data.get('email') or '').lower().strip()
    password = data.get('password')

    if not email or not password:
        return jsonify({'msg': 'email and password required'}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({'msg': 'email already exists'}), 400

    user = User(first_name=first or '', last_name=last or '', email=email)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    token = create_access_token(identity=user.id)
    return jsonify({'access_token': token, 'user': user.to_dict()}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = (data.get('email') or '').lower().strip()
    password = data.get('password')

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({'msg': 'invalid email or password'}), 401

    user.last_login = datetime.datetime.utcnow()
    db.session.commit()
    token = create_access_token(identity=user.id)
    return jsonify({'access_token': token, 'user': user.to_dict()}), 200

@app.route('/api/me', methods=['GET'])
@jwt_required()
def me():
    uid = get_jwt_identity()
    user = User.query.get(uid)
    if not user:
        return jsonify({'msg': 'user not found'}), 404
    return jsonify({'user': user.to_dict()}), 200

# -------------------------------------------------------------------
# AI utilities
# -------------------------------------------------------------------
def analyze_code_with_ai(code: str, language: str):
    openai_key = os.getenv('OPENAI_API_KEY')
    if openai_key and openai:
        try:
            openai.api_key = openai_key
            model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
            system = ("You are CodeHealer: analyze the user's code, find errors/warnings, "
                      "and produce a JSON object with keys: errors, warnings, fixes, summary. Return valid JSON.")
            user_msg = f"Language: {language}\n\nCode:\n```\n{code}\n```"
            resp = openai.ChatCompletion.create(
                model=model,
                messages=[{"role":"system","content":system},
                          {"role":"user","content":user_msg}],
                temperature=0
            )
            content = resp['choices'][0]['message']['content']
            return json.loads(content)
        except Exception as e:
            print("OpenAI call failed:", e)

    # fallback simple analysis
    errors, warnings, fixes = [], [], []
    summary = "Basic static analysis."
    if 'python' in (language or '').lower():
        try:
            ast.parse(code)
        except SyntaxError as e:
            errors.append({'line': e.lineno, 'msg': str(e)})
    else:
        if re.search(r'return\s+\w+\s*\+\s*\w+', code):
            warnings.append("Possible type coercion between numbers and strings.")
            fixes.append({
                'name': 'Number() conversion',
                'description': 'Convert operands to numbers explicitly before adding.',
                'code': "function calculateSum(a, b) { return Number(a) + Number(b); }"
            })
    if not errors and not warnings:
        summary = "No syntax errors found."
    elif errors:
        summary = f"{len(errors)} error(s) found."
    else:
        summary = f"{len(warnings)} warning(s) found."
    return {'errors': errors, 'warnings': warnings, 'fixes': fixes, 'summary': summary}

# -------------------------------------------------------------------
# API endpoints
# -------------------------------------------------------------------
@app.route('/api/debug', methods=['POST'])
@jwt_required()
def debug():
    data = request.get_json() or {}
    code = data.get('code', '')
    language = data.get('language', 'text')
    if not code.strip():
        return jsonify({'msg':'code is required'}), 400

    result = analyze_code_with_ai(code, language)

    uid = get_jwt_identity()
    user = User.query.get(uid)
    if user:
        user.debug_count = (user.debug_count or 0) + 1
        db.session.commit()

    return jsonify({'result': result}), 200

@app.route('/api/chat', methods=['POST'])
@jwt_required()
def chat():
    data = request.get_json() or {}
    message = (data.get('message') or '').strip()
    if not message:
        return jsonify({'msg':'message is required'}), 400

    openai_key = os.getenv('OPENAI_API_KEY')
    if openai_key and openai:
        try:
            openai.api_key = openai_key
            model = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
            system = "You are CodeHealer assistant. Offer short, helpful debugging answers."
            resp = openai.ChatCompletion.create(
                model=model,
                messages=[{"role":"system","content":system},
                          {"role":"user","content": message}],
                temperature=0.2
            )
            reply = resp['choices'][0]['message']['content']
            return jsonify({'reply': reply}), 200
        except Exception as e:
            print("OpenAI chat failed:", e)

    # fallback simple replies
    canned = {
        'explain': "This error often happens when mixing strings and numbers.",
        'fix': "Try using Number() or parseInt().",
        'best practice': "Add input validation and proper error handling.",
        'alternative': "Use TypeScript or explicit type-checking."
    }
    for key, val in canned.items():
        if key in message.lower():
            return jsonify({'reply': val}), 200
    return jsonify({'reply': "I'm here to help — please paste code or error."}), 200

# -------------------------------------------------------------------
# Health
# -------------------------------------------------------------------
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status':'ok'}), 200

# -------------------------------------------------------------------
# Main
# -------------------------------------------------------------------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
